package multithreads.multithreads;

public class unsysnchronizedBuffer implements buffer {
	private int buffer = -1;
	private int i = 0;
	private int[] bufferIntArray = new int[10];
	//Criar atributos com os vetores necessários
	public void putBuffer(int value) 
			throws InterruptedException{
		System.out.printf("Escrita valor: \t\t%d", value);
		buffer = value;
	}
	public int getBuffer() throws InterruptedException{
		System.out.printf("Leitura valor: \t\t%d", buffer);
		return buffer;
	}

	public void putBufferIntArray(int value) throws InterruptedException{
		System.out.printf("Escrita valor: \t\t%d", value);
		bufferIntArray[value-1] = value;
	}

	public int getBufferIntArray()
			throws InterruptedException{
		int readValue = bufferIntArray[i];
		System.out.printf("Leitura valor: \t\t%d", bufferIntArray[i]);
		if(readValue != 0)
			i++;
		return readValue;
	}

	//Adicionar métodos de escrita e leitura para os vetores criados
}
